var oMainWrap = document.getElementById('mainWrap');
var oTab = getByClass(oMainWrap,'tab')[0]
var aTabLi = oTab.getElementsByTagName('li');

for(var i=0;i<aTabLi.length;i++){
    aTabLi[i].index = i;
    aTabLi[i].onmouseover = function(){
        aTabLi[this.index].style.backgroundColor = 'rgba(166,203,250,0.35)';
    }
    aTabLi[i].onmouseout = function(){
        aTabLi[this.index].style.backgroundColor = 'rgba(166,203,250,0)';
    }
}

var oNav = getByClass(oMainWrap,'nav')[0];
var oRili = oNav.getElementsByTagName('li')[0];
var oSelect =  getByClass(oMainWrap,'select')[0];

oSelect.style.height = "0px";
oRili.onmouseover = function(){
    startMove(oSelect,{height:60});
}

//                                oSelect.onmouseover = function(){
//                                    this.style.display = "block";
//                                }
oRili.onmouseout = function(){
    setTimeout(function(){
        startMove(oSelect,{height:0});
    },3000)
}